<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// Auto Models By Baboon Script
// Baboon Maker has been Created And Developed By  [It V 1.0 | https://it.phpanonymous.com]
// Copyright Reserved  [It V 1.0 | https://it.phpanonymous.com]
class Expenses_main extends Model
{

   protected $table    = 'expense_type_main';
   protected $fillable = [
      'id',
      'exp_m_name',
      'created_at',
      'updated_at',
   ];



}
