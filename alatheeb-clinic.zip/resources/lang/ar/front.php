<?php
return [
    'status'    =>  [
        'pending'   =>  'بالنتظار',
    ],
    'emp' => "دخول الموظفين فقط "
];
