<?php
return [

    'emp' => "Staff entry only"
];
