{{ trans('admin.'.$attend_status) }}
