<a href="{{ it()->url($form) }}" target="_blank"><i class="fa fa-download fa-2x"></i></a>
