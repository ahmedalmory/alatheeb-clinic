@include('admin.layouts.header')
@include('admin.layouts.navbar')
@include('admin.layouts.menu')
@include('admin.layouts.messages')

@yield('content')

@include('admin.layouts.footer')