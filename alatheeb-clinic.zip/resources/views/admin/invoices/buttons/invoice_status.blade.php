{{ trans('admin.'.$invoice_status) }}
