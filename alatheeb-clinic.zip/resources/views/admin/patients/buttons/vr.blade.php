{{ trans('admin.'.$vr) }}
