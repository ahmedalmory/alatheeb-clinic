{{ !empty($level)?trans('admin.'.$level):'' }}
