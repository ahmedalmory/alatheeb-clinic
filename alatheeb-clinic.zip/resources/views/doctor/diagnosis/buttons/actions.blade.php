<a href="{{ url('doctor/diagnosis/'.$id)}}"  class="btn btn-default btn-sm"><i class="fa fa-eye"></i> {{trans('admin.show')}}</a>
