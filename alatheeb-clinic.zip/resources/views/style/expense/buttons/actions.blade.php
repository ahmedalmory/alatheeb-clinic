<a href="{{ url('/invoice_print_expense/'.$id)}}" target="_blank" style="display: inline;"  class="btn btn-sm btn-success" title="{{trans('admin.show')}}"><i class="fa fa-eye"></i> </a>
