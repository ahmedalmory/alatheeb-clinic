<a  onclick="edit_expense_sub(<?php echo($id); ?>);" class="btn btn-info btn-sm">
<i class="fa fa-pencil-square-o"></i> {{trans('admin.edit')}}</a>
