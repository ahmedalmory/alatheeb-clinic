<div class="row">
<div class="col-md-2">ااسم مصرف الرئيسي</div>
<div class="col-md-6">
<input type="text" class="form-control" name="exp_m_name" id="exp_m_name" placeholder="اسم مصرف الرئيسي"></div>
<div class="col-md-4">
<button type="button" onclick="save_expense_main()" class="btn btn-success" >حفظ</button></div>

</div>
