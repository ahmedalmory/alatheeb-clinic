@include('style.layouts.header_doctor')
@include('style.layouts.navbar_doctor')
@include('style.layouts.message')
<div class="" style="min-height:75vh">
  @yield('content')
</div>
</div>
</div>
@include('style.layouts.footer')
