@extends('style.index')
@section('content')
@push('js')

@endpush



 <div class="clearfix"></div>
   <div id="homepagearea">
     ddd

</div>

 <div class="clearfix"></div>

@stop
