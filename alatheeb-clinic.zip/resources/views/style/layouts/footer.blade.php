

    </div><!-- End homepagearea -->
  </div><!-- end container -->

	<a href="#" class="scrollup fa fa-angle-up"></a>
<div class="">
  <div class="last-footer container-fluid">
          <div class="copy-rights text-center w-100 mt-3 " style="padding:10px;display: flex; align-items: center; justify-content: space-between; width: 100%;">
            <a href="https://www.const-tech.com.sa/"
               target="_black"
               class="text-white mb-0 tech">
                  © Copyright 2022. Const-tech All Rights Reserved.
            </a>
            <img style="width:70px" src="{{url('images/logo-light.png')}}" alt="">

          </div>

        </div>
</div>






	<!--[if lt IE 8 ]>
	<script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.2/CFInstall.min.js"></script>
	<script>window.attachEvent("onload",function(){CFInstall.check({mode:"overlay"})})</script>
	<![endif]-->
  <!-- Latest compiled and minified CSS -->

  <!-- Optional theme -->

  <!-- Latest compiled and minified JavaScript -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>

	<script type="text/javascript" src="{{url('design/style')}}/js/modernizr.custom.97442.js"></script>
	<script type="text/javascript" src="{{url('design/style')}}/js/bootstrap-rtl.min.js"></script>
	<script type="text/javascript" src="{{url('design/style')}}/js/more.js"></script>
	<script src="{{url('design/admin_panel')}}/assets/global/plugins/moment.min.js" type="text/javascript"></script>

	<script src="{{url('design/admin_panel')}}/assets/global/plugins/moment.min.js" type="text/javascript"></script>
	<script src="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js" type="text/javascript"></script>
	<script src="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
	<script src="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
	<script src="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>






	<script src="{{url("design/calendar/js/jquery.calendars.min.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.calendars.plus.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.plugin.min.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.calendars.all.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.calendars.picker-ar.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.calendars.validation.min.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.calendars.islamic.min.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.calendars.islamic-ar.js")}}"></script>
	<script src="{{url("design/calendar/js/jquery.calendars-ar-EG.js")}}"></script>
	<link rel="stylesheet" type="text/css" href="{{url("design/calendar/css/ui.calendars.picker.css")}}">
	<link rel="stylesheet" type="text/css" href="{{url("design/calendar/css/jquery.calendars.picker.css")}}">
	<link rel="stylesheet" type="text/css" href="{{url("design/calendar/css/smoothness.calendars.picker.css")}}">

	<link href="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />
	<link href="{{url('design/admin_panel')}}/assets/global/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
	<link href="{{url('design/admin_panel')}}/assets/global/plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet" type="text/css" />
	<link href="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
	<link href="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css" />
	<link href="{{url('design/admin_panel')}}/assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" />




<script type="text/javascript" src="{{url("design/admin_panel/assets/global/plugins/datatables/js/jquery.dataTables.min.js")}}"></script>
<script type="text/javascript" src="{{url("design/admin_panel/assets/global/plugins/datatables/js/dataTables.bootstrap.min.js")}}"></script>
<script type="text/javascript" src="{{url("design/admin_panel/assets/global/plugins/datatables/js/dataTables.buttons.min.js")}}"></script>
<script type="text/javascript" src="{{url("design/admin_panel/assets/global/plugins/datatables/js/selecta_all_checkbtn.js")}}"></script>
<script type="text/javascript" src="{{url("design/admin_panel/assets/global/plugins/datatables/js/buttons.server-side.js")}}"></script>
<script type="text/javascript" src="{{url("design/admin_panel/assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js")}}"></script>

		<!-- Javascript -->
<script type="text/javascript" src="{{ url('design/style') }}/js/modernizr.custom.97442.js"></script>
<script type="text/javascript" src="{{ url('design/style') }}/js/bootstrap-rtl.min.js"></script>
<script type="text/javascript" src="{{ url('design/style') }}/js/more.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/jstree.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>

<script src="{{asset("js/bootstrap-hijri-datetimepicker.js")}}"></script>


  <script type="text/javascript">
    $(document).ready(function(){
      $("div.formstep2").hide("fast");
      $("a.nextstep").click(function(){
        $("div.formstep1").hide("fast");
        $("div.formstep2").show("fast");
      });
      $("button.prevstep").click(function(){
        $("div.formstep2").hide("fast");
        $("div.formstep1").show("fast");
      });
      $(document).on('click','.btn[data-dismiss="modal"]', function() {
        console.log("hhh");
        $('.modal-backdrop').remove()
      })
    });
  </script>
	<!-- Javascript -->

	<script type="text/javascript">
	  $(document).ready(function(){
          $(function () {
              $(".hijri").hijriDatePicker({
                  hijriText: "عرض التاريخ الهجري",
                  gregorianText: "عرض التاريخ الميلادي"
              });
          });
          $(".hijri").on('dp.change', function (arg) {

              if (!arg.date) {

                  return;
              }else{
                  let date = arg.date;
                  var age = new Date().getFullYear() - parseInt(date.format("YYYY"));
                  $('.age').val(age);
              }

          });
	    {{--$('.date-picker').datepicker({--}}
	    {{--    todayBtn:true,--}}
	    {{--    clearBtn:true,--}}
	    {{--    format:'yyyy-mm-dd',--}}
	    {{--});--}}

	    {{--$('.hijri').calendarsPicker($.extend({--}}
	    {{--    calendar: $.calendars.instance('islamic', 'ar'),--}}
	    {{--    dateFormat:'yyyy-mm-dd',--}}
	    {{--    regionalOptions:'ar',--}}
	    {{--    localNumbers:true--}}
	    {{--},$.calendarsPicker.regionalOptions['ar']));--}}

	    {{--$(document).on('change','.hijri',function(){--}}
	    {{--    var date = $(this).val();--}}
	    {{--    $('.age').val({{ Arabicdatetime::date(time() , 1 , 'Y'  ) }} - date.split('-')[0]);--}}
	    {{--});--}}
	});
	</script>
	<!-- Javascript -->
	 <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/autosize@4.0.2/dist/autosize.min.js"></script>

	@stack('js')
</body>
</html>
