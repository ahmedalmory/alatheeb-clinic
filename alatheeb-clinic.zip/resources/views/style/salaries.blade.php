@extends('style.index')

@section('content')
    <h4>رواتب الموظفين</h4>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">{{ __('admin.month') }}</th>
            <th scope="col">{{ __('admin.user_id') }}</th>
            <th scope="col">{{ __('admin.salary') }}</th>
            <th scope="col">{{ __('admin.discount') }}</th>
            <th scope="col">{{ __('admin.monthly_income') }}</th>
            <th scope="col">{{ __('admin.rate') }}</th>
            <th scope="col">{{ __('admin.total_with_rate') }}</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($users as $user)
                
          <tr>
            <th scope="row">{{ $loop->index+1 }}</th>
            <th scope="row">{{ __('admin.month') }} {{ now()->format('m') }}</th>
            <td>{{ $user->name }}</td>
            <td>{{ $user->salary }}</td>
            <td>0</td>
            <td>{{ $user->monthly_income }}</td>
            <td>{{ $user->rate }}%</td>
            <td>{{ $user->salary + $user->monthly_income }}</td>
          </tr>
          @endforeach
          {{ $users->links() }}
        </tbody>
      </table>
@endsection
