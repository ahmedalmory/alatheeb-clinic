<a href="{{ url('/tasdeed_invoice/'.$id)}}"  style="display: inline;"  class="btn btn-sm btn-success" title="{{trans('admin.show')}}">اصدار فاتورة </a>
