<div class="row">
<div class="col-md-2">اسم التصنيف:</div>
<div class="col-md-6">
<input type="text" class="form-control" name="cat_name" id="cat_name" placeholder="اسم التصنيف"></div>
<div class="col-md-4">
<button type="button" onclick="save_category()" class="btn btn-success" >حفظ</button></div>

</div>
